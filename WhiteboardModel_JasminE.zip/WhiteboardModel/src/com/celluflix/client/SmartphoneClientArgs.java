package com.celluflix.client;

public class SmartphoneClientArgs {

}